DELETE Categories
DELETE Users_Favorits
DELETE Points_review
DELETE Points
DELETE Users_Questions
DELETE Users_Categories
DELETE Users