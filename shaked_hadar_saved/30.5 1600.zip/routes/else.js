const express = require('express');
const router = express.Router();
var DButilsAzure = require('../DButils');

// test route to make sure everything is working (accessed at GET http://localhost:3000/auth) good
router.get('/', (req, res) => {
    res.send("Hello world -  else");
});

// test route to make sure everything is working (accessed at GET http://localhost:3000/else/getCategories) good
router.get('/getCategories', function (req, res){

    DButilsAzure.execQuery(`SELECT * FROM dbo.Categories`)
    .then((response, err) => {
        if(err)
            res.status(400).json({message: err.message});
        else{
            //let jsonObject = JSON.parse(response);
            res.status(200).json({categories: response});
            }
        
    })
    .catch(function(err) {
        res.status(400).json({message: err.message});
    });

});

// test route to make sure everything is working (accessed at GET http://localhost:3000/else/getRandomPopularPoints) good
router.get('/getRandomPopularPoints', (req, res) => {

    let threshold = 70;

    DButilsAzure.execQuery(`SELECT dbo.Points.PointName FROM dbo.Points WHERE Rate >= '${threshold}'`)
    .then((response, err) => {
        if(err)
            res.status(400).json({message: err.message});
        else{
            var numbers = [];
            var NumOfpoints=[];
            var ans = {};
            var size = response.length;
            if(size>3){
                for (var i = 0; i < 10; i++) {
                    numbers.push(Math.floor(Math.random() * Math.floor(size)));
                }
                let index =0;
                for(var x in numbers){
                    if(NumOfpoints.includes(numbers[x]) !== true && index<3){
                        NumOfpoints.push(numbers[x]);
                        index = index+1;
                    }
                    
                }

                for(var p in NumOfpoints)
                {
                    ans[p] = response[NumOfpoints[p]];
                }

                res.status(200).json({randomPopular: ans});

            }
            else{
                res.status(200).json({randomPopular: response});
            }
        }
        
    })
    .catch(function(err) {
        res.status(400).json({message: err.message});
    });


});

// test route to make sure everything is working (accessed at POST http://localhost:3000/else/getPoint)
router.post('/getPoint', (req, res) => {

    PointName = req.body.PointName;;
    var i;
    let ID;
    let pName;
    let Imag;
    let Vnum;
    let rate;
    let des;
    let rev1;
    let rev2;
    DButilsAzure.execQuery(`SELECT * FROM dbo.Points WHERE PointName = '${PointName}'`)
    .then((response, err) => {
        if(err)
            res.status(400).json({message: err.message});
        else{
            ID =  response[0].PointID;
            pName =  response[0].PointName;
            Imag = response[0].Image;
            Vnum =  response[0].ViewNum ;
            rate= response[0].Rate ;
            des = response[0].Description ;
            }
        
    })
    .catch(function(err) {
        res.status(400).json({message: err.message});
    });

    DButilsAzure.execQuery(`SELECT * FROM dbo.Points_review WHERE PointName = '${PointName}'`)
    .then((response, err) => {
        if(err)
            res.status(400).json({message: err.message});
        else{

            rev1= response[0].Review1;
            DateReview1= response[0].DateReview1 ;
            rev2 = response[0].Review2;
            DateReview2 = response[0].DateReview2 ;
            res.status(200).json({PointID: ID}, {PointName: pName},{Image: Imag},{NumberOfViews: Vnum},{Rate:rate },{Desrciption: des},{Review1: rev1},{DateOfReview1: DateReview1},{Review2:rev2},{DateOfReview2: DateReview2});
            }
        
    })
    .catch(function(err) {
        res.status(400).json({message: err.message});
    });
});



router.get('/getAllPoints', (req, res) => {

    var i;

    DButilsAzure.execQuery(`SELECT * FROM dbo.Points`)
    .then((response, err) => {
        if(err)
            res.status(400).json({message: err.message});
        else{
            var answer = [];
            for (i in response){
                answer[i] = response[i].PointName + ", Category Name: "+response[i].CategoryName +", Rate: "+response[i].Rate ;  
            }
            console.log(answer);
            res.status(200).json({Points: answer});
            }
        
    })
    .catch(function(err) {
        res.status(400).json({message: err.message});
    });
});




module.exports = router;